import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'orders_screen.dart';
import 'cart_screen.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Determine screen width for responsive layout
    final isDesktop = MediaQuery.of(context).size.width >= 1024;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ONE MAN'),
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            icon: const Icon(Icons.chevron_left, size: 30),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag_outlined),
            onPressed: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const CartScreen()));
            },
          ),
        ],
      ),
      body: isDesktop
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 7, child: _buildForms(context)),
                const SizedBox(width: 48),
                Expanded(flex: 5, child: _buildRightSummaryPanel(context)),
              ],
            )
          : ListView(
              children: [
                _buildForms(context),
                _buildRightSummaryPanel(context),
                const SizedBox(height: 120),
              ],
            ),
      bottomNavigationBar: isDesktop ? null : _buildMobileStickyCTA(context),
    );
  }

  Widget _buildForms(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFormSection(
            step: "01/03",
            title: "Shipping Address",
            content: Column(
              children: [
                _buildTextInput("FULL NAME", "Julianne Moore"),
                const SizedBox(height: 24),
                _buildTextInput("STREET ADDRESS", "1242 Mercer St, Soho"),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(child: _buildTextInput("CITY", "New York")),
                    const SizedBox(width: 24),
                    Expanded(child: _buildTextInput("POSTAL CODE", "10012")),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 48),
          _buildFormSection(
            step: "02/03",
            title: "Payment Method",
            content: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _buildPaymentMethodCard(
                        icon: Icons.credit_card,
                        title: "Credit Card",
                        subtitle: "VISA, MASTERCARD",
                        isSelected: true,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _buildPaymentMethodCard(
                        icon: Icons.account_balance_wallet_outlined,
                        title: "Digital Wallet",
                        subtitle: "APPLE PAY, PAYPAL",
                        isSelected: false,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 32),
                _buildTextInput(
                  "CARD NUMBER",
                  "0000 0000 0000 0000",
                  suffixIcon: Icons.contactless_outlined,
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(child: _buildTextInput("EXPIRY DATE", "MM/YY")),
                    const SizedBox(width: 24),
                    Expanded(child: _buildTextInput("CVV", "123")),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormSection({
    required String step,
    required String title,
    required Widget content,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.onSurface,
              ),
            ),
            Text(
              "STEP $step",
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: AppColors.onSurfaceVariant,
              ),
            ),
          ],
        ),
        const SizedBox(height: 32),
        content,
      ],
    );
  }

  Widget _buildTextInput(String label, String hint, {IconData? suffixIcon}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.0,
            color: AppColors.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surfaceContainer,
            borderRadius: BorderRadius.circular(8),
          ),
          child: TextField(
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 16,
              ),
              hintText: hint,
              hintStyle: TextStyle(
                fontFamily: 'Inter',
                fontSize: 14,
                color: AppColors.outlineVariant,
              ),
              suffixIcon: suffixIcon != null
                  ? Icon(suffixIcon, color: AppColors.onSurfaceVariant)
                  : null,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentMethodCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool isSelected,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isSelected
            ? AppColors.surfaceContainerLowest
            : AppColors.surfaceContainer,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isSelected
              ? AppColors.outlineVariant.withOpacity(0.5)
              : Colors.transparent,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: isSelected ? AppColors.primary : AppColors.onSurfaceVariant,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.onSurface,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 10,
                    letterSpacing: 1.0,
                    color: AppColors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Radio indicator
          Container(
            width: 16,
            height: 16,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: isSelected
                    ? AppColors.primaryDim
                    : AppColors.outlineVariant,
                width: 2,
              ),
            ),
            padding: const EdgeInsets.all(2),
            child: isSelected
                ? Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.primaryDim,
                    ),
                  )
                : null,
          ),
        ],
      ),
    );
  }

  Widget _buildRightSummaryPanel(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surfaceContainerLow,
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Order Summary",
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.onSurface,
              ),
            ),
            const SizedBox(height: 32),
            _buildSummaryItem(
              "Structured Wool Coat",
              "Oatmeal / Medium",
              "\$450.00",
              "https://lh3.googleusercontent.com/aida-public/AB6AXuAYb-c4QA2F91s_5FGZra3KpCVB8afDyNPYYoBFxhKDkPLjjPuvhJgMcIBwK4-KPpI6xFGTXuAL_PKfeBbVhR8kf4WF3hWmSUlQV1hV-XP7NDKB3klYW2c6jQnV_41VWcXZJP8Tm2YUdykwfCwCiBspnSLccULMbljd2ndr1Sd0eSAMgjrDNUw-adyHOv9Iuh9ZDsOiHAllXqRmSfowWZ-wfrTs4sLQG9-hug2TfJmPEBLW4uLQ18TsT1OTIREYG4eP9zggoCDIJ4g",
            ),
            const SizedBox(height: 24),
            _buildSummaryItem(
              "Noire Shoulder Bag",
              "Obsidian / OS",
              "\$320.00",
              "https://lh3.googleusercontent.com/aida-public/AB6AXuAytq0EC3TA0UMzEWRyzStvhUefnYdP-rI4RoJHhQr97vdVITiuU6Nt5XRhUts2lr5lt5o_YXyoB5PIHxqwIq8PbV3pzCsHsT-N-vOLGCu2JQo8v_zTG0IY0ExL6V-yelypC8wm5a-m1O-lhJQzYLThTQfP6WxtLK52dSX2GcMHBbmxUTRO6BkrW1QHkfqwo8olcTMkHoqiJu4lWanhvQrv1SCweKSr6-Tc29-cH58zXL_PPggV520I0O4-BJ8x6Y1pNlLbigNdp7U",
            ),
            const SizedBox(height: 32),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.surfaceContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  _buildSubRow("Subtotal", "\$770.00"),
                  const SizedBox(height: 16),
                  _buildSubRow("Shipping", "Free"),
                  const SizedBox(height: 16),
                  _buildSubRow("Tax", "\$61.60"),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Total",
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.onSurface,
                        ),
                      ),
                      Text(
                        "\$831.60",
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.onSurface,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            if (MediaQuery.of(context).size.width >= 1024)
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const OrdersScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.inverseSurface,
                  foregroundColor: AppColors.inversePrimary,
                  minimumSize: const Size.fromHeight(64),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                child: const Text(
                  "PLACE ORDER",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.0,
                  ),
                ),
              ),
            const SizedBox(height: 24),
            Center(
              child: Text(
                "By placing your order, you agree to ONE MAN's\nTerms of Service and Privacy Policy.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 10,
                  color: AppColors.onSurfaceVariant,
                  letterSpacing: 1.5,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem(
    String title,
    String subtitle,
    String price,
    String imgUrl,
  ) {
    return Row(
      children: [
        Container(
          width: 80,
          height: 96,
          decoration: BoxDecoration(
            color: AppColors.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
            image: DecorationImage(
              image: NetworkImage(imgUrl),
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: AppColors.onSurface,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 12,
                  color: AppColors.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                price,
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.onSurface,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSubRow(String label, String val) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 14,
            color: AppColors.onSurfaceVariant,
          ),
        ),
        Text(
          val,
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: AppColors.onSurface,
          ),
        ),
      ],
    );
  }

  Widget _buildMobileStickyCTA(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLowest,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 40,
            offset: const Offset(0, -10),
          ),
        ],
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "TOTAL AMOUNT",
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.0,
                  color: AppColors.onSurfaceVariant,
                ),
              ),
              Text(
                "\$831.60",
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const OrdersScreen()),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.inverseSurface,
              foregroundColor: AppColors.inversePrimary,
              minimumSize: const Size.fromHeight(56),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            child: const Text(
              "CONFIRM AND PAY",
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
