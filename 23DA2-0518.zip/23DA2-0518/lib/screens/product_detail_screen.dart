import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatelessWidget {
  const ProductDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text('ONE MAN'),
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16, top: 4, bottom: 4),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.surfaceContainerLowest.withOpacity(0.5),
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag_outlined),
            onPressed: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const CartScreen()));
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          ListView(
            padding: EdgeInsets.zero,
            children: [
              _buildHeroImage(),
              _buildDetailsSection(),
              const SizedBox(height: 120), // padded for sticky CTA
            ],
          ),
          _buildStickyCTA(context),
        ],
      ),
    );
  }

  Widget _buildHeroImage() {
    return AspectRatio(
      aspectRatio: 3 / 4,
      child: Container(
        color: AppColors.surfaceContainerLow,
        child: Stack(
          children: [
            Image.network(
              'https://lh3.googleusercontent.com/aida-public/AB6AXuCwsBXZfUJ-AYiBilSeq9O6QKy7AogOYGL7UEAn2yRlyYZEt9cE5x6JLdqpZQCdhpzl_Jz8zCqpZJ-tFjmNDH0aY6QoKiyycU4W6tKkIH1NR92nEABMek7lMOVxwLyCSZdqjckPq_uIDUbKD62GLnQb3j6oPQIRpx5-lm2vW5Va2fqBvopcz5sdFtBViyVyCGshvxeIIUAqbjxEuQrDu44617ymXMGucIgeU-dLiVMwwmzheUf1nkCGXv6MITTUgqRNBSbONiPfFm4',
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
            Positioned(
              bottom: 48,
              right: 24,
              child: Column(
                children: [
                  _buildFloatingIcon(Icons.favorite_border),
                  const SizedBox(height: 16),
                  _buildFloatingIcon(Icons.share_outlined),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingIcon(IconData icon) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLowest.withOpacity(0.8),
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: AppColors.onSurface),
    );
  }

  Widget _buildDetailsSection() {
    return Transform.translate(
      offset: const Offset(0, -32),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surfaceContainerLowest,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 40,
              offset: const Offset(0, -20),
            ),
          ],
        ),
        padding: const EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "NEW COLLECTION",
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2.0,
                          color: AppColors.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Sculpted Wool Overcoat",
                        style: TextStyle(
                          fontFamily: 'Manrope',
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          height: 1.1,
                          letterSpacing: -0.5,
                          color: AppColors.onSurface,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  "\$840",
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: AppColors.onSurface,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text(
              "An architectural silhouette crafted from sustainably sourced Italian virgin wool. Features a clean concealed placket and hand-finished seams for a seamless tactile experience.",
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 14,
                height: 1.6,
                color: AppColors.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 40),
            _buildColorSelection(),
            const SizedBox(height: 24),
            _buildSizeSelection(),
            const SizedBox(height: 24),
            _buildExtraInfoGrid(),
          ],
        ),
      ),
    );
  }

  Widget _buildColorSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "COLOR SELECTION",
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            color: AppColors.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            _buildColorCircle(const Color(0xFFE5DACE), isSelected: true),
            const SizedBox(width: 16),
            _buildColorCircle(const Color(0xFF1A1A1A)),
            const SizedBox(width: 16),
            _buildColorCircle(const Color(0xFF4A5043)),
          ],
        ),
      ],
    );
  }

  Widget _buildColorCircle(Color color, {bool isSelected = false}) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: isSelected
            ? Border.all(color: AppColors.onSurface, width: 2)
            : null,
      ),
    );
  }

  Widget _buildSizeSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "SELECT SIZE",
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: AppColors.onSurfaceVariant,
              ),
            ),
            Text(
              "Size Guide",
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 10,
                decoration: TextDecoration.underline,
                letterSpacing: 1.5,
                color: AppColors.onSurfaceVariant,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildSizeBox("S"),
            _buildSizeBox("M", isSelected: true),
            _buildSizeBox("L"),
            _buildSizeBox("XL"),
          ],
        ),
      ],
    );
  }

  Widget _buildSizeBox(String size, {bool isSelected = false}) {
    return Expanded(
      child: Container(
        height: 56,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.inverseSurface
              : AppColors.surfaceContainerLow,
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.center,
        child: Text(
          size,
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 14,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            color: isSelected ? AppColors.inversePrimary : AppColors.onSurface,
          ),
        ),
      ),
    );
  }

  Widget _buildExtraInfoGrid() {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.surfaceContainer,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.eco_outlined, color: AppColors.primary, size: 24),
                const SizedBox(height: 12),
                Text(
                  "MATERIAL",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    color: AppColors.onSurface,
                  ),
                ),
                Text(
                  "100% Recycled Italian Wool",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 11,
                    color: AppColors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.surfaceContainer,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.local_shipping_outlined,
                  color: AppColors.primary,
                  size: 24,
                ),
                const SizedBox(height: 12),
                Text(
                  "DELIVERY",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                    color: AppColors.onSurface,
                  ),
                ),
                Text(
                  "Complimentary Express",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 11,
                    color: AppColors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStickyCTA(BuildContext context) {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surfaceContainerLowest.withOpacity(0.9),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                height: 64,
                decoration: BoxDecoration(
                  color: AppColors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Icon(
                  Icons.shopping_bag_outlined,
                  color: AppColors.onSurfaceVariant,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 4,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(
                    context,
                  ).push(MaterialPageRoute(builder: (_) => const CartScreen()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.inverseSurface,
                  foregroundColor: AppColors.inversePrimary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(999),
                  ),
                  minimumSize: const Size.fromHeight(64),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "ADD TO CART",
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: AppColors.inversePrimary,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(Icons.arrow_forward),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
