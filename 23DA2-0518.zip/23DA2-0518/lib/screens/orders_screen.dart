import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'main_navigation_scaffold.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ONE MAN'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.home_outlined),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MainNavigationScaffold()),
              (route) => false,
            );
          },
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        children: [
          Text(
            "MY ORDERS",
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 32,
              fontWeight: FontWeight.w800,
              letterSpacing: -1.0,
              color: AppColors.onSurface,
            ),
          ),
          const SizedBox(height: 32),
          _buildOrderCard(
            "AT-88294X",
            "Delivered",
            "Structured Wool Coat",
            "Oatmeal / Medium",
            "\$450.00",
            "https://lh3.googleusercontent.com/aida-public/AB6AXuAYb-c4QA2F91s_5FGZra3KpCVB8afDyNPYYoBFxhKDkPLjjPuvhJgMcIBwK4-KPpI6xFGTXuAL_PKfeBbVhR8kf4WF3hWmSUlQV1hV-XP7NDKB3klYW2c6jQnV_41VWcXZJP8Tm2YUdykwfCwCiBspnSLccULMbljd2ndr1Sd0eSAMgjrDNUw-adyHOv9Iuh9ZDsOiHAllXqRmSfowWZ-wfrTs4sLQG9-hug2TfJmPEBLW4uLQ18TsT1OTIREYG4eP9zggoCDIJ4g",
          ),
          const SizedBox(height: 24),
          _buildOrderCard(
            "AT-88211A",
            "Shipped",
            "Raw Silk Wide Trousers",
            "Charcoal / Small",
            "\$680.00",
            "https://lh3.googleusercontent.com/aida-public/AB6AXuBvmxtJojY0gWxEgQ9_xrOEKphG8SOrKeQ6Th734trpZYK1i1e8VULOImiCD6Kdf5csErAKa-lDLdUaYylX91EOkOun63dJ4uAYBE9M7Qyqpy02oFzLjjrhiH7c-e0mz8wjJReP4ynxBAh8JnQrlYSGsFmfi6Tdu_tswngcsUZePlllUaadeMEshI3Bg3JnoeRFucSZ2NNaqGs7w-6dlr1IUfSsTpcfHMhTHLH8ix4tNa1Uc7pOScv7XlyPt3IW5OLjMcswaiehr0M",
          ),
          const SizedBox(height: 120),
        ],
      ),
    );
  }

  Widget _buildOrderCard(
    String orderId,
    String status,
    String title,
    String subtitle,
    String price,
    String imgUrl,
  ) {
    final bool isDelivered = status.toLowerCase() == 'delivered';

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 20,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "ORDER $orderId",
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.0,
                  color: AppColors.onSurfaceVariant,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: isDelivered
                      ? AppColors.surfaceContainer
                      : Colors.black12,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  status.toUpperCase(),
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.0,
                    color: isDelivered
                        ? AppColors.onSurfaceVariant
                        : AppColors.onSurface,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Container(
                width: 80,
                height: 96,
                decoration: BoxDecoration(
                  color: AppColors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(8),
                  image: DecorationImage(
                    image: NetworkImage(imgUrl),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 12,
                        color: AppColors.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      price,
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: AppColors.onSurface,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          OutlinedButton(
            onPressed: () {},
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(48),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              side: BorderSide(
                color: AppColors.outlineVariant.withOpacity(0.5),
              ),
            ),
            child: Text(
              "VIEW DETAILS",
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: AppColors.onSurface,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
