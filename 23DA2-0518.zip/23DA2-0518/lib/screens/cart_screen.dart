import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'checkout_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ONE MAN'),
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        children: [
          _buildHeader(),
          const SizedBox(height: 32),
          _buildCartItems(),
          const SizedBox(height: 48),
          _buildOrderSummary(context),
          const SizedBox(height: 120),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "MY BAG",
          style: TextStyle(
            fontFamily: 'Manrope',
            fontSize: 32,
            fontWeight: FontWeight.w800,
            letterSpacing: -1.0,
            color: AppColors.onSurface,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "3 items curated for you",
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 14,
            color: AppColors.onSurfaceVariant,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildCartItems() {
    final items = [
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuAEe-Cg9J7EfWuHkPB1stY2DO4EEpX2_f68FlfwtI49KwqqZA7EGH8eVB5pFtH9VyVcJp8fLz1P7ae2qRzpdabBWNNvIgv9ZJWicq5LqIn_cxl-sKX1ox6hbMJxyjlPjt8eke1ljkjT0BhSh_JGI1JB5m43r4YppVKcnwKyBxhLwsQ4EuzA8m5q5mpKLpQvHWbRffgVP7ZV7Ea5_z5mdslnb36scejNwMkenu1bKuG3Zf-Xc0dnM0IpKvsl9sJ1jeHGtLkw79flkBc",
        "title": "Sculpted Wool Overcoat",
        "size": "42 (M)",
        "price": "\$1,240.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuBvmxtJojY0gWxEgQ9_xrOEKphG8SOrKeQ6Th734trpZYK1i1e8VULOImiCD6Kdf5csErAKa-lDLdUaYylX91EOkOun63dJ4uAYBE9M7Qyqpy02oFzLjjrhiH7c-e0mz8wjJReP4ynxBAh8JnQrlYSGsFmfi6Tdu_tswngcsUZePlllUaadeMEshI3Bg3JnoeRFucSZ2NNaqGs7w-6dlr1IUfSsTpcfHMhTHLH8ix4tNa1Uc7pOScv7XlyPt3IW5OLjMcswaiehr0M",
        "title": "Raw Silk Wide Trousers",
        "size": "38 (S)",
        "price": "\$680.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDMnl284c5Kjwpp40s22VzvCc-eRiT9o0f2-II5qL1XmgwmV0_S3YAIuH7Aj0VsarZc-Zdk00WTtbXWfh__xUcRnxg6yRAX8zg7M11k_wd-HiMBYP5gQbBPgGEsNfRGw_Q48wABCy_LbNFFWEVXn-CrPvxF43xI2VvSwM_EKdysxOTKEmYmhnvBnpmEy9oL6OITxwJzSpAeuGFxe3l3DkKDCuQDypgc-MYxX5pZmIzhgmkvZSh9HvXUGN7p-T-Bg2jsiXEu4KtdNIM",
        "title": "One Man Soft Tote",
        "size": "ONE SIZE",
        "price": "\$2,100.00",
      },
    ];

    return Column(
      children: items.map((item) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 32),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 100,
                height: 140,
                decoration: BoxDecoration(
                  color: AppColors.surfaceContainer,
                  borderRadius: BorderRadius.circular(8),
                  image: DecorationImage(
                    image: NetworkImage(item["image"]!),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 24),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            item["title"]!.toUpperCase(),
                            style: TextStyle(
                              fontFamily: 'Manrope',
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              height: 1.2,
                              color: AppColors.onSurface,
                            ),
                          ),
                        ),
                        Icon(
                          Icons.close,
                          size: 20,
                          color: AppColors.onSurfaceVariant,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "SIZE: ${item["size"]}",
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: AppColors.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      item["price"]!,
                      style: TextStyle(
                        fontFamily: 'Manrope',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      decoration: BoxDecoration(
                        color: AppColors.surfaceContainerLow,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.remove,
                            size: 16,
                            color: AppColors.onSurface,
                          ),
                          const SizedBox(width: 16),
                          Text(
                            "1",
                            style: TextStyle(
                              fontFamily: 'Inter',
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: AppColors.onSurface,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Icon(Icons.add, size: 16, color: AppColors.onSurface),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildOrderSummary(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.onSurface.withOpacity(0.04),
            blurRadius: 40,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "SUMMARY",
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 2.0,
              color: AppColors.onSurface,
            ),
          ),
          const SizedBox(height: 24),
          _buildSummaryRow("Subtotal", "\$4,020.00"),
          const SizedBox(height: 12),
          _buildSummaryRow("Standard Shipping", "Complimentary"),
          const SizedBox(height: 12),
          _buildSummaryRow("Estimated Tax", "\$341.70"),
          const SizedBox(height: 24),
          Divider(color: AppColors.outlineVariant.withOpacity(0.3)),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "TOTAL",
                style: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.0,
                  color: AppColors.onSurface,
                ),
              ),
              Text(
                "\$4,361.70",
                style: TextStyle(
                  fontFamily: 'Manrope',
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: AppColors.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const CheckoutScreen()));
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.inverseSurface,
              foregroundColor: AppColors.inversePrimary,
              minimumSize: const Size.fromHeight(64),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            child: Text(
              "PROCEED TO CHECKOUT",
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 2.0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Inter',
            fontSize: 14,
            color: AppColors.onSurfaceVariant,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontFamily: 'Manrope',
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: AppColors.onSurface,
          ),
        ),
      ],
    );
  }
}
