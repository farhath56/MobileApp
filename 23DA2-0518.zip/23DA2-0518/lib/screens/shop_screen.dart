import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'product_detail_screen.dart';
import 'cart_screen.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ONE MAN'),
        centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.search), onPressed: () {}),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag_outlined),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CartScreen()),
              );
            },
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          _buildStickyHeader(),
          _buildProductGrid(context),
          const SliverToBoxAdapter(
            child: SizedBox(height: 120), // Padding for bottom nav
          ),
        ],
      ),
    );
  }

  Widget _buildStickyHeader() {
    return SliverPersistentHeader(
      pinned: true,
      delegate: _StickyTabBarDelegate(
        child: Container(
          color: AppColors.background.withOpacity(0.95),
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                _buildFilterChip("All Items", isActive: true),
                _buildFilterChip("Men"),
                _buildFilterChip("Women"),
                _buildFilterChip("Summer"),
                _buildFilterChip("Winter"),
                Container(
                  height: 24,
                  width: 1,
                  color: AppColors.outlineVariant.withOpacity(0.3),
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                ),
                GestureDetector(
                  onTap: () {},
                  child: Row(
                    children: [
                      const Icon(
                        Icons.tune,
                        size: 18,
                        color: AppColors.onSurfaceVariant,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        "FILTER",
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                          color: AppColors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, {bool isActive = false}) {
    return Container(
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      decoration: BoxDecoration(
        color: isActive
            ? AppColors.inverseSurface
            : AppColors.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label.toUpperCase(),
        style: TextStyle(
          fontFamily: 'Inter',
          fontSize: 12,
          fontWeight: FontWeight.w500,
          letterSpacing: 2.0,
          color: isActive
              ? AppColors.inversePrimary
              : AppColors.onSurfaceVariant,
        ),
      ),
    );
  }

  Widget _buildProductGrid(BuildContext context) {
    final products = [
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuCiEsG3jc-j5Qo_cO23wj-rFf7cX6n-UvyUrwTWYYQRqwUbFt6816drUPNYAG6sMtJtMIoTxw5C1i4ukTjzpH3UR27xC8cDJos1w58sN8_O_gbWyJJFHiK1tlNRTT2BquveluOB17kTboUKQYO2viixl_10dzwlu7VZojWla15drHo9VJ7ec5eTMZuSdSALO8TmORD9Hvh3B8GH7uAENlRgx3q4eyNgslXuqRe-YVz5x3MUo7xsnj1gp7QAG648rH5P5QVp3Z62Gr4",
        "category": "TAILORED COLLECTION",
        "title": "Structured Wool Blazer",
        "price": "\$245.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDhjdSXHckautGfLoXo_FY1E9ki0PFIT_n123X24I1JS5R24cOAx0LukPy93a_gH0K7gumZOHpQQgmhD7zpUPaVIMVsX8BmE0c2xjLHptjFqXFAX2Lk6yJ9DUerYcqac4OY6k51oPn8HNAez8Zw-mqG-_rJd5GO4ewF2iOxmB2tfddb1aR8BIt0z1ZZpPKkOovaFabFdmES24HlnCDlabz8Hd5P45PXeNKQNaERbAPQlR61x9Ncjxa6HfqVlKGrFb4N6Muux9ROxAs",
        "category": "ESSENTIAL LAYER",
        "title": "Pure Cashmere Sweater",
        "price": "\$180.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuD1U7yWl4RpRsmIfbeNWq5EG7Z3jdq02Ldfc1BTpD__y0zctmmt7Rjoi5qVyLsQW72nHXiRKosR35xDOhaaWj0ViSpLzEy_8ELcQZogfPUy4aGGlyWOOEzNYo3Dy1ILDP9TxPRM4mgkEKtoxWGiPRT0_wxdBMjXwVWvLkGA5jEwiSN0MhL-9SNdQPRa3k8WQoAwaQFPdGxwUOHn-12BtrlYfaSr6jSSMv55C3pMU_NJkBnzHUtIHLYUqlSHwjfxfC0aR7IEoI0QZBI",
        "category": "ARCHIVE SERIES",
        "title": "Classic Trench Coat",
        "price": "\$310.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuCxFI5MfbH4OpFmd77NQWbSFx-Mv2NKhTmj1mGyEFY7R_JOdNs-AGyiyy__r09FtnzpP29FlQUU2TA3vCMYXtLf61pSfg30JYV4sFjCqUxa4mHT7Fzh2ytFI4CWCE5v_dYovOPR2Zr_CBUuu_Yty-MKZTDArHwUGOLN14U5-drrKIcvx-8EXNDkPRZCfwY-mEdXt06ijD04xlUfijwrhN0LahMzEHP2PYMQAv7UAz8h2bkHJ6gD3K0apBEe_J0DxdqCVMzDj_8FHxo",
        "category": "FOOTWEAR",
        "title": "Sculpted Leather Boots",
        "price": "\$295.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuDBWRze1TCGsaXzNvzXck6otgJ5aVvygP9ICdMl5X6q94L30L8e1vkaA95BCxtqa_HABetb8fXjENwcs2E6c92xSUv6jP3jRjmWf-mC6twy88NiAnmT9iCWPhJ3PD9C2aCmjm8JqZpLp-dk8uQCeX5k_qs6KbD5rcVHWraNAZm59PWwCOn0-X1SxvJPWBfoScukc_FLFEtEq1lZaztAqcbM6QDU_hJ5OoSNnnfsWHUYEisO7W352kGa6y36Fp0-_QGTjQgMpDsBcFk",
        "category": "ACCESSORIES",
        "title": "Tan Leather Tote",
        "price": "\$195.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuAolhx9gVm25UfyT193h9ZphmVc-B_qUbI2n0urukGvIOL7ezrDsAITF_uh307KrlNhWuZsLBGyIBuAfmXxFqYDLvbVV9EOsaq5tU66mRaTHTdf59QrEQ3MniqS_zuooG4ZqOMK1mfx6WE-cLCcdBsz6c675M8RtmtIPEYzlBzVny2pPI7gCRQiEbtrK1a1RIZKhn6Y4X635OgDMEYq9ZoZbhZUR71QsYuGzAZYIXDZJSSElwXxOcxgRzs3FJvBKvqG6unebpiVerc",
        "category": "SUMMER CAPSULE",
        "title": "Silk Slip Dress",
        "price": "\$165.00",
      },
    ];

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 32,
          crossAxisSpacing: 16,
          childAspectRatio: 0.55, // Tweaked for image + text
        ),
        delegate: SliverChildBuilderDelegate((context, index) {
          final item = products[index];
          return GestureDetector(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProductDetailScreen()),
              );
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: AppColors.surfaceContainer,
                      image: DecorationImage(
                        image: NetworkImage(item["image"]!),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Container(
                            height: 32,
                            width: 32,
                            decoration: BoxDecoration(
                              color: AppColors.surfaceContainerLowest
                                  .withOpacity(0.4),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.favorite_border, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  item["category"]!,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.5,
                    color: AppColors.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  item["title"]!,
                  style: TextStyle(
                    fontFamily: 'Manrope',
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: -0.5,
                    color: AppColors.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  item["price"]!,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppColors.onSurface,
                  ),
                ),
              ],
            ),
          );
        }, childCount: products.length),
      ),
    );
  }
}

class _StickyTabBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;

  _StickyTabBarDelegate({required this.child});

  @override
  double get minExtent => 64.0;
  @override
  double get maxExtent => 64.0;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return child;
  }

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) {
    return true;
  }
}
