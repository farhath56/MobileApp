import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'shop_screen.dart'; // Just to show you could navigate, though bottom nav is primary
import 'cart_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ONE MAN'),
        centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.search), onPressed: () {}),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag_outlined),
            onPressed: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const CartScreen()));
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 120),
        children: [
          _buildHeroSection(context),
          _buildNewArrivals(),
          _buildTrendingNow(),
          _buildNewsletter(),
        ],
      ),
    );
  }

  Widget _buildHeroSection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: Container(
        height: 500,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: AppColors.surfaceContainerLow,
          image: const DecorationImage(
            image: NetworkImage(
              'https://lh3.googleusercontent.com/aida-public/AB6AXuDkASpqV9_cQY25MhbgLaAkRxfzjAKE0RONcH5FoiQtQO_0Zj3s9r_lXBDhCnGWUSuQa4nQuhoRRG5-9rthGfjhIKjxGMtQSAzHZOtezRXpcKBi61v_XexXRek_cuf7nBli5TUeDZlHikZ8ojYAhjR1e1rmOauETjWCFTqPflQf8IdUBpTB0vR3lven62A81-IuZUGMVDDQVGDvVxsuMPk2zZ4gK9BzcxSsn58uSzUFaw1Tw7IpPXKAJ3QISQ3M6mcTY6ZCnmwu5mE',
            ),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            // Gradient Overlay
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: LinearGradient(
                  colors: [
                    AppColors.inverseSurface.withOpacity(0.6),
                    Colors.transparent,
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
            ),
            // Content
            Positioned(
              bottom: 40,
              left: 32,
              right: 32,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "SEASON'S COLLECTION",
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 2.0,
                      color: AppColors.onPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "ESSENTIALS\nFOR THE MODERNIST",
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 36,
                      fontWeight: FontWeight.w800,
                      height: 1.1,
                      color: AppColors.onPrimary,
                      letterSpacing: -1.0,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Discover our curated selection of timeless silhouettes and sustainable fabrics.",
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 14,
                      color: AppColors.onPrimary.withOpacity(0.8),
                    ),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.inverseSurface,
                      foregroundColor: AppColors.inversePrimary,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(999),
                      ),
                      elevation: 0,
                    ),
                    child: const Text(
                      "SHOP COLLECTION",
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewArrivals() {
    final arrivals = [
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuAwDzAXD9rBYlkLRvqYZc-3r3g3i7J0qUeQwe6lGwg7AHOH42Hyc-TbgejiDXIpaSTTjnIuoHaMIPVuD85i1fYpgRxpeoi2-W8MtJ7MnHic00SpGGxdfJTnOPhxpFUZ4khphqeroyT7qAS02sOoWI_oO8tsq2MlAC-9yy9L8yuj7mRvx9hxk1QfvyudxFyie32T6pTHth0UIxjymjYbxjZk6eCpqsVVR5kI3wi8i_z4fuDMvbzwtl1P-R7MbMjXdYZrWzS3ZDats1w",
        "category": "OUTERWEAR",
        "title": "Structured Wool Blazer",
        "price": "\$245.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuAbYlhFbsZBB4BafkGjnJqnubzrZkmC1fGnepFDX7MmnxEATUOyoxSmu2pa4p5KlsHVIv68rAqm5UrjKLvkf0WncpOmMeArtdDJsdhaLnkrAS5IUdzbyooU9xq75_KqPAvfcmBuDHKPphY7wtivPhQ90tZYXnod9lFIv1tZ-FX_w7MNGvMkGJ8oTGwFH2GvIeKzXsE4Lzzn-NWKhQqJyD24FxCsv27pbWoGwvRZ25i19-Q0hDBiZdYQc3pSYldYugUFvRllFbUVqLw",
        "category": "DRESSES",
        "title": "Pleated Silk Midi",
        "price": "\$189.00",
      },
      {
        "image":
            "https://lh3.googleusercontent.com/aida-public/AB6AXuCdMsko34KQ1oZrzHPmxn81DR6vnTFF0S3vjh8LXd_UZKISfiOVQj_DpYQwfRfJS9CABk5LZuhgezTI95hpunZfTGf8h4eFdiOhX4xtSXfKCoLeHQoNBdGbSloB6H3JZ_4iP2bZGbHQghQN9RwsLmDcO0UOwzx_5DX0GCbMZ9pgS8ZVjgNojQ2WaXUHmdBZwn-yunYGt_jgYMXyxcufV6q5GdoEhK6-IG2G_hf16QH6jKpxtans9TMAnY8HNuCfGZomH1_O0Xdsm7g",
        "category": "FOOTWEAR",
        "title": "Leather T-Strap Sandal",
        "price": "\$130.00",
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "NEW ARRIVALS",
                    style: TextStyle(
                      fontFamily: 'Manrope',
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5,
                      color: AppColors.onSurface,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "THE LATEST DROPS",
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.5,
                      color: AppColors.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.only(bottom: 2),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: AppColors.outlineVariant,
                      width: 1,
                    ),
                  ),
                ),
                child: Text(
                  "VIEW ALL",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1.5,
                    color: AppColors.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        SizedBox(
          height: 350,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            scrollDirection: Axis.horizontal,
            itemCount: arrivals.length,
            separatorBuilder: (context, index) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              final item = arrivals[index];
              return SizedBox(
                width: 256, // 64 * 4
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 280, // Fix height based on visual
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: AppColors.surfaceContainer,
                        image: DecorationImage(
                          image: NetworkImage(item["image"]!),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      item["category"]!,
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 2.0,
                        color: AppColors.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item["title"]!,
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: AppColors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      item["price"]!,
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 14,
                        color: AppColors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildTrendingNow() {
    return Padding(
      padding: const EdgeInsets.only(top: 64, left: 24, right: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "TRENDING NOW",
            style: TextStyle(
              fontFamily: 'Manrope',
              fontSize: 24,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
              color: AppColors.onSurface,
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            height: 400,
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: AppColors.surfaceContainerHighest,
                      image: const DecorationImage(
                        image: NetworkImage(
                          'https://lh3.googleusercontent.com/aida-public/AB6AXuDcRJk4lDdX_EW8JqyWMfvnlnsZVh2xa8R3a5jjMtCjG7dHHnhA18yWCZbJK81iuTcj7QYSLeLLGofU4RMNb4iWLMEu82GvKKlUO1OsWcc4ikX0l4WMmya7gbAWG-gEBAD1wznx2H67d1i9Anj-TVSVNUR_ARZDQI8RBn7Odu0BdAkgT0ZWY-SqM7uF1RNCM92evjGJJlAF46ylQjCQ5juq1_vcTs-TS-KB5RPMOgRpzf45RqTZDJ3qZ144GJkb_AQm3b_s8l_whSg',
                        ),
                        fit: BoxFit.cover,
                        colorFilter: ColorFilter.mode(
                          Colors.black12,
                          BlendMode.darken,
                        ),
                      ),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          bottom: 24,
                          left: 24,
                          child: Text(
                            "THE TAILOR",
                            style: TextStyle(
                              fontFamily: 'Manrope',
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2.0,
                              color: AppColors.onPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: AppColors.surfaceContainer,
                            image: const DecorationImage(
                              image: NetworkImage(
                                'https://lh3.googleusercontent.com/aida-public/AB6AXuCOu1nios4VP71nVENx8ujV63FRAvEVPYq-qbBFv7jxZwGWS3H-n5kfWVVeo6wTrwpP9mhTSDyqhqN5nL_qT6LbLYO0hCI_uWc7mYyQkLpsz0T8adgj22uLqbJztAfp_Ih6sQyE0plhej3d0KPETgJ805Brn-VqPqy3QMtYH5e6LzSYVamYMUg_GzG57R0t34LvcVJmH9mIvIMDfZ5bHV4nvXn84OY0ltc2EJs0RZCOWh0Q6dgFKAlrEhTbJXzudVD9ZysP4Hvtlws',
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                bottom: 16,
                                left: 16,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.surface.withOpacity(0.8),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    "ACCENTS",
                                    style: TextStyle(
                                      fontFamily: 'Manrope',
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.5,
                                      color: AppColors.onSurface,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: AppColors.surfaceContainerLow,
                            image: const DecorationImage(
                              image: NetworkImage(
                                'https://lh3.googleusercontent.com/aida-public/AB6AXuBzJ8VWkJK_Ct2SOaSgaobjlZw0T4kuYXKr6buJ541aBs2tvkJ60sGqqUdpOViPu_FsOFwVCWI9taDbvnH1A01OvSuFO6kUFv3U9tA7SUdH3Z25b7zLdq82mDMnSaSFK2_I0fxKTNkcd5APKiVU64XLtkmOVcFuimP8OEVZ2WeB0dtQXNsWhSIRLkPTXescD3ocrTjsAsFhNA56Gh8N9x41IJhTaPZ-yFEDFekbj-k4G4n17qiBcKWzf_1XDvtUrgukaYGvPg9dL1c',
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                bottom: 16,
                                left: 16,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.surface.withOpacity(0.8),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                  child: Text(
                                    "PURE KNIT",
                                    style: TextStyle(
                                      fontFamily: 'Manrope',
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.5,
                                      color: AppColors.onSurface,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsletter() {
    return Padding(
      padding: const EdgeInsets.only(top: 80, left: 24, right: 24),
      child: Container(
        padding: const EdgeInsets.all(40),
        decoration: BoxDecoration(
          color: AppColors.surfaceContainer,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          children: [
            Text(
              "THE ONE MAN JOURNAL",
              style: TextStyle(
                fontFamily: 'Manrope',
                fontSize: 20,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
                color: AppColors.onSurface,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Early access to collections and curated style insights delivered weekly.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 14,
                color: AppColors.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 24),
            Container(
              height: 56,
              decoration: BoxDecoration(
                color: AppColors.surfaceContainerLowest,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: TextField(
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Email Address",
                          hintStyle: TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 14,
                            color: AppColors.outline,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.inverseSurface,
                        foregroundColor: AppColors.inversePrimary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text(
                        "JOIN",
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
