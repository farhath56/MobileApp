import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/main_navigation_scaffold.dart';

void main() {
  runApp(const OneManApp());
}

class OneManApp extends StatelessWidget {
  const OneManApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ONE MAN',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const MainNavigationScaffold(),
    );
  }
}
