import 'package:flutter/material.dart';

class AppColors {
  // Brand
  static const Color primary = Color(0xFF5E5E5E);
  static const Color primaryDim = Color(0xFF525252);
  static const Color primaryContainer = Color(0xFFE2E2E2);
  static const Color onPrimary = Color(0xFFF8F8F8);

  static const Color secondary = Color(0xFF5F5F5F);
  static const Color secondaryDim = Color(0xFF535353);

  // Background and Surface
  static const Color background = Color(0xFFF9F9F9);
  static const Color onBackground = Color(0xFF2D3435);

  static const Color surface = Color(0xFFF9F9F9);
  static const Color onSurface = Color(0xFF2D3435);
  static const Color onSurfaceVariant = Color(0xFF5A6061);

  static const Color surfaceContainerLowest = Color(0xFFFFFFFF);
  static const Color surfaceContainerLow = Color(0xFFF2F4F4);
  static const Color surfaceContainer = Color(0xFFEBEEEF);
  static const Color surfaceContainerHigh = Color(0xFFE4E9EA);
  static const Color surfaceContainerHighest = Color(0xFFDDE4E5);

  static const Color outline = Color(0xFF757C7D);
  static const Color outlineVariant = Color(0xFFADB3B4);

  // Inverse
  static const Color inverseSurface = Color(0xFF0C0F0F);
  static const Color inversePrimary = Color(0xFFFFFFFF);
  static const Color inverseOnSurface = Color(0xFF9C9D9D);

  static const Color error = Color(0xFF9F403D);
  static const Color onError = Color(0xFFFFF7F6);
}
